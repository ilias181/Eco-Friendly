const chatbox = document.querySelector(".chatbox");
const createChatLi = (message, className) => {
	const chatLi = document.createElement("li");
	chatLi.classList.add("chat", className);
	let chatContent = 
		className === "chat-outgoing" ? "<p>" + message + "</p>" : "<p>" + message + "</p>";
	chatLi.innerHTML = chatContent;
	return chatLi;
}

function sendBtn() {
	var sendtext = $("#sendtext").val().trim();
	if (!sendtext) {
		return;
	}
	chatbox.appendChild(createChatLi(sendtext, "chat-outgoing"));
	chatbox.scrollTo(0, chatbox.scrollHeight);
	$.ajax({
		url: "http://127.0.0.1:5000/sendtext",
		type: "POST",
		contentType: "application/json", // Specify JSON content type
		data: JSON.stringify({ text: sendtext }), // Convert data to JSON string
		dataType: 'json',
		success: function(response) {
			chatbox.appendChild(createChatLi(response.text, "chat-incoming"));
			chatbox.scrollTo(0, chatbox.scrollHeight);
		},
		error: function(xhr) {
			chatbox.appendChild(createChatLi("Oops! Something went wrong. Please try again!", "chat-incoming"));
			chatbox.scrollTo(0, chatbox.scrollHeight);
		}
	});
}
function openForm() {
  document.getElementById("myForm").style.display = "block";
}
function closeForm() {
  document.getElementById("myForm").style.display = "none";
} 

function showProfile() {
  var profile = document.querySelector(".profile-data");
  if (profile.style.display === "block") {
	profile.style.display = 'none'
  } else {
	profile.style.display = 'block'
  }
}
if (localStorage.getItem('full_name')) document.getElementById('full_name').innerHTML = localStorage.getItem('full_name')

function login() {
    var email = $("#email").val().trim();
    var password = $('#password').val().trim();
    $.ajax({
        url: "http://127.0.0.1:5000/login",
        type: "POST",
        contentType: "application/json", // Specify JSON content type
        data: JSON.stringify({ email: email, password: password }), // Convert data to JSON string
        dataType: 'json',
        success: function(response) {
            console.log(response);
            alert('Успешно');
            localStorage.setItem('full_name', response.name)
            window.location.href = './main_page.html';
        },
        error: function(xhr) {
            if (xhr.status === 401) {
                alert('Неверный пароль');
            } else {
                alert('Произошла ошибка. Пожалуйста, попробуйте еще раз.');
            }
        }
    });
}

