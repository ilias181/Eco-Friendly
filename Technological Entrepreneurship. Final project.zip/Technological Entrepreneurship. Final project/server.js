const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');

const app = express();
app.use(bodyParser.json());

// Telegram Bot Token и Chat ID
const BOT_TOKEN = '7225342266:AAGtePiFpd9PaZuT1pipzoHicwMA7CucdJY'; // Вставьте токен вашего бота
const CHAT_ID = '6684030075'; // Вставьте ваш Chat ID

// Маршрут для отправки уведомлений
app.post('/send-notification', (req, res) => {
  const { name, phone, address, items } = req.body;

  // Формируем текст сообщения
  const message = `
    📦 New Order Received:
    🏷️ Name: ${name}
    📱 Phone: ${phone}
    📍 Address: ${address}
    🛒 Items:
    ${items.map(item => `- ${item.name} x${item.quantity}`).join('\n')}
  `;

  // Отправляем сообщение через Telegram API
  axios
    .post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      chat_id: CHAT_ID,
      text: message
    })
    .then(() => res.send({ success: true, message: 'Notification sent to Telegram!' }))
    .catch(error => {
      console.error('Error sending message to Telegram:', error.message);
      res.status(500).send({ success: false, error: error.message });
    });
});

app.listen(3000, () => console.log('Server is running on http://localhost:3000'));

