from flask import Flask, request, jsonify
from flask_cors import CORS
from g4f.client import Client
client = Client()
conversation_history = []

app = Flask(__name__)
CORS(app)
# Sample users
users = [
    {"email": "slambekov8888@gmail.com", "password": "qwerty123", "name": 'Ilyas Slambekov'},
    {"email": "test@gmail.com", "password": "test123", "name": "Test User"}
]

# /login endpoint to check existing user
@app.route('/login', methods=['POST'])
def login():

    data = request.get_json()
    print(data)
    email = data.get("email")
    password = data.get("password")

    # Find the user by email
    user = next((u for u in users if u["email"] == email), None)
    if user and user["password"] == password:
        return jsonify({"message": "Login successful", "status": 200, "name": user["name"]}), 200
    else:
        return jsonify({"message": "Invalid email or password", "status": 401, "name": user["name"]}), 401

@app.route('/sendtext', methods=['POST'])
def sendtext():
    data = request.get_json()
    user_input = data.get("text")
    print(user_input)
    conversation_history.append({"role": "user", "content": user_input})
    correct_response = False
    while(not correct_response):
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=conversation_history
        )
        if (response.choices[0].message.content.find(
            "Model not found or too long input. Or any other error (xD)") == -1):
            correct_response = True
    conversation_history.append({"role": "assistant", "content": response.choices[0].message.content})
    return jsonify({"text": response.choices[0].message.content}), 200

if __name__ == '__main__':
    f = open("promt.txt", "r")
    conversation_history.append({"role": "user", "content": f.read()})
    app.run(debug=True)




    
    

